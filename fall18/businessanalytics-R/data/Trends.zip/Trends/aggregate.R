setwd("C:/Users/jap090020/Dropbox/UTDallas/buan6356/post/trends")
rm(list=ls())
library(data.table)

fread('states.txt')
states <- fread('states.txt',header=FALSE)
terms <- fread('terms.txt',header=FALSE)
ns <- NROW(states)
nt <- NROW(terms)

files <- list()
count <- 1
for(s in 1:ns){
  for(t in 1:nt){
    str <- paste(terms[t],"-",states[s],".csv",sep="")
    files[[count]] <- fread(str)
    count <- count + 1
  }
}
nf <- NROW(files)

for(i in 1:nf){
  df <- files[[i]]
  for(c in 2:ncol(df)){
    str <- colnames(df)[c]
    str <- strsplit(str,":")[[1]][1]
    colnames(df)[c] <- str
  }
  files[[i]] <- df
}

for(s in 1:ns){
  indx <- (s-1)*nt
  minv <- 101
  for(t in 1:nt){
    df <- files[[t+indx]]
    val <- max(df[,2])
    if(val<minv){minv<-val}
  }
  for(t in 1:nt){
    df <- files[[t+indx]]
    val <- minv/max(df[,2])
    df[,2:ncol(df)] <- val*df[,2:ncol(df)]
    files[[t+indx]] <- df 
  }
  print(c(states$V1[s],minv))
}

statefiles <- list()
for(s in 1:ns){
  indx <- (s-1)*nt
  df <- files[[1+indx]]
  for(t in 2:nt){
    df2 <- files[[t+indx]]
    df <- cbind(df,df2[,3:ncol(df2)])
  }
  statefiles[[s]] <- df
}
statefiles[[1]]
df <- statefiles[[1]]

bigT <- nrow(df)
for(s in 1:ns){
  df <- statefiles[[s]]
  df$State <- rep(states[s],bigT)
  df$Date <- paste(df$Month,'01',sep='-')
  df <- df[,c(213,214,2:212)]
  statefiles[[s]] <- df
}
df <- statefiles[[1]]
for(s in 2:ns){
  df <- rbind(df,statefiles[[s]])
}
fwrite(df,file='trends.csv')
