setwd("C:/Users/jap090020/Dropbox/UTDallas/buan6356/post/trends")
rm(list=ls())
library(data.table)

wonder <- fread('wonder.csv')
trends <- fread('trends.csv')
popn <- fread('popn.csv')
wonder <- wonder[Date>='2014-01-01']
trends <- trends[,unique(names(trends)),with=FALSE]

df <- merge(trends,popn,by=c('State','Date'),all=FALSE)
df <- merge(df,wonder,by=c('State','Date'),all=TRUE)
View(df)
df$Date <- as.Date(df$Date)

df$suic <- df$suic/df$popn
df$guns <- df$guns/df$popn
df$heroin <- df$heroin/df$popn
df$suicide <- df$`suicide -girls -squad`

summary(lm(suic~as.factor(month(Date))+as.factor(State)*as.numeric(Date)+suicide,data=df))
