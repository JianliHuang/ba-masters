setwd("C:/Users/jap090020/Dropbox/UTDallas/buan6356/post/trends")
rm(list=ls())
library(data.table)

df <- fread('us.1969_2016.19ages.txt',header=FALSE)
head(df)
nrow(df)
df$Date <- as.numeric(substr(df$V1,1,4))
df$State <- substr(df$V1,5,6)
df$Fips <- substr(df$V1,7,12)
df$popn <- as.numeric(substr(df$V1,19,27))
df <- df[,sum(popn),by=.(State,Date)]
colnames(df)[3] <- 'popn'
df <- df[Date>=2004]

bigT <- 2016-2004+1
bigT <- (bigT-1)*12+1
dts <- approx(df2$Date,log(df2$popn),n=bigT)$x
df_new <- data.table(State=rep(NA,51*bigT),Date=rep(NA,51*bigT),popn=rep(NA,51*bigT))

for(s in 1:51){
  st <- unique(df$State)[s]
  df2 <- df[State==st]
  indx <- (s-1)*bigT
  df_new$State[(indx+1):(indx+bigT)] <- rep(st,bigT)
  df_new$Date[(indx+1):(indx+bigT)] <- dts
  df_new$popn[(indx+1):(indx+bigT)] <- exp(approx(df2$Date,log(df2$popn),n=bigT)$y)
}
df <- df_new
library(Hmisc)
st <- unique(df$State)[1]
df2 <- df[State==st][Date==2015|Date==2016]
xout <- seq(2016+1/12,2018,1/12)
nxout <- NROW(xout)
df_new <- data.table(State=rep(NA,51*nxout),Date=rep(NA,51*nxout),popn=rep(NA,51*nxout))

for(s in 1:51){
  st <- unique(df$State)[s]
  df2 <- df[State==st][Date==2015|Date==2016]
  indx <- (s-1)*nxout
  df_new$State[(indx+1):(indx+nxout)] <- rep(st,nxout)
  df_new$Date[(indx+1):(indx+nxout)] <- xout
  df_new$popn[(indx+1):(indx+nxout)] <- exp(approxExtrap(df2$Date,log(df2$popn),xout=xout)$y)
}
df <- rbind(df,df_new)
df <- df[order(State,Date),,]
fwrite(df,file='popn.csv')
